print("Hello, AWS")
